"use strict";
import{e8 as e,e9 as o}from"./js/core.c9lnUO1f.js";const t=Object.freeze(Object.defineProperty({__proto__:null,LandingRender:o,SetupPageBuilder:e},Symbol.toStringTag,{value:"Module"}));export{t as i};
