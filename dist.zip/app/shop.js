"use strict";
import{e4 as e,e5 as o}from"./js/core.CCmPQ7Fe.js";const t=Object.freeze(Object.defineProperty({__proto__:null,LandingRender:o,SetupPageBuilder:e},Symbol.toStringTag,{value:"Module"}));export{t as i};
