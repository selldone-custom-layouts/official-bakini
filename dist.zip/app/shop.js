"use strict";
import{e6 as e,e7 as o}from"./js/core.CvUzey6e.js";const t=Object.freeze(Object.defineProperty({__proto__:null,LandingRender:o,SetupPageBuilder:e},Symbol.toStringTag,{value:"Module"}));export{t as i};
