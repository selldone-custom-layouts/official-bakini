"use strict";
import{e1 as e,e2 as o}from"./js/core.bAZhyXKl.js";const t=Object.freeze(Object.defineProperty({__proto__:null,LandingRender:o,SetupPageBuilder:e},Symbol.toStringTag,{value:"Module"}));export{t as i};
