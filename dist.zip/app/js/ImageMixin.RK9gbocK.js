"use strict";
import{E as s}from"./core.c9lnUO1f.js";const t={methods:{showFullscreen(e){s.$emit("show:fullscreen",e)}}};export{t as I};
