"use strict";
import{E as s}from"./core.CCmPQ7Fe.js";const t={methods:{showFullscreen(e){s.$emit("show:fullscreen",e)}}};export{t as I};
