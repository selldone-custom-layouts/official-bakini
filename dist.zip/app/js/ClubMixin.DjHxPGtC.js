"use strict";
import{C as t}from"./core.c9lnUO1f.js";const r={methods:{getCustomerClubLevel(e){return t.Levels[e]}}};export{r as C};
