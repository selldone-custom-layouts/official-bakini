"use strict";
import{C as t}from"./core.CCmPQ7Fe.js";const r={methods:{getCustomerClubLevel(e){return t.Levels[e]}}};export{r as C};
