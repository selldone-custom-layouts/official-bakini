"use strict";
const t={methods:{formatCard(r){return r&&r.replace(/(\d{4})(\d{4})(\d{4})(\d+)/,"$1-$2-$3-$4")}}};export{t as A};
