"use strict";
import{C as t}from"./core.DtqERwSo.js";const r={methods:{getCustomerClubLevel(e){return t.Levels[e]}}};export{r as C};
