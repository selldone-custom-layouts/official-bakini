"use strict";
import{C as t}from"./core.C_CI2Sq-.js";const r={methods:{getCustomerClubLevel(e){return t.Levels[e]}}};export{r as C};
